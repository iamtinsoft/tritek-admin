const DefaultLayout = ({ children }: any) => {
  return <div>{children}</div>;
};

export default DefaultLayout;
