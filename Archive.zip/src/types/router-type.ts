export interface routerType {
  element: JSX.Element;
  path: string;
}
