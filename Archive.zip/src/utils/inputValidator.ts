export const validateInput = (property: any) => {
  if (property) {
    return true;
  }
  return false;
};
